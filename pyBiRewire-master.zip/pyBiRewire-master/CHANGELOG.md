#V 0.6
* Bug fixing due to jgraph renamed package, DSG network removed for maintenance

#V 0.5
* EXTESION to directed signed networks

#V 0.4
* possibility so set seed for srand C function

#V 0.3
* bug fixing
* now the analysis is perfomed using n_networks number of graphs generated independently form the initial one
* added a monitoring function for the underlying markov chain
* added an external function computing the similarity between two consistent graph representations

#V 0.2
* bug fixing
* added little documentation
* sparse undirected network routines wrapped

# V 0.1
* frist brunch of wrapped function
* basic functionalities
