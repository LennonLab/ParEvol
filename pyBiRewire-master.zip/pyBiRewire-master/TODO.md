* ALIGNMENT CODE WITH R-package (https://bioconductor.org/packages/release/bioc/html/BiRewire.html)
* DOCUMENTATION
* CLEAN and DEBUG the code

